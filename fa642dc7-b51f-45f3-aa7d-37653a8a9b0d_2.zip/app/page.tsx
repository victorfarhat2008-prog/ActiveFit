
'use client';

import Header from '@/components/Header';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-screen flex items-center justify-center bg-cover bg-center"
        style={{
          backgroundImage: "url('https://readdy.ai/api/search-image?query=Modern%20minimalist%20fashion%20background%20with%20soft%20textures%20and%20clean%20aesthetic%2C%20neutral%20tones%2C%20elegant%20fabric%20patterns%2C%20premium%20clothing%20brand%20atmosphere%2C%20sophisticated%20styling%2C%20high-end%20fashion%20photography%20with%20natural%20lighting&width=1920&height=1080&seq=hero-bg-001&orientation=landscape')"
        }}
      >
        <div className="absolute inset-0 bg-black/30"></div>
        <div className="relative text-center text-white px-6 w-full">
          <h1 className="text-5xl md:text-7xl font-bold mb-6">Premium Essentials</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
            Discover our carefully curated collection of premium t-shirts designed for comfort and style
          </p>
          <Link 
            href="/products"
            className="bg-white text-black px-8 py-4 text-lg font-semibold rounded-md hover:bg-gray-100 transition-colors whitespace-nowrap cursor-pointer inline-block"
          >
            Shop Collection
          </Link>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Featured Products</h2>
            <p className="text-xl text-gray-600">Essential pieces for your wardrobe</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="group">
              <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-6">
                <img 
                  src="https://readdy.ai/api/search-image?query=Premium%20white%20cotton%20t-shirt%20displayed%20elegantly%20on%20clean%20background%2C%20professional%20product%20photography%2C%20soft%20natural%20lighting%2C%20high-end%20fashion%20styling%2C%20minimalist%20aesthetic%2C%20studio%20setup%20with%20subtle%20shadows&width=600&height=600&seq=featured-white-001&orientation=squarish"
                  alt="White T-Shirt"
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">Classic White T-Shirt</h3>
              <p className="text-gray-600 mb-4">Premium cotton blend for ultimate comfort</p>
              <p className="text-2xl font-bold text-black">$29</p>
            </div>
            
            <div className="group">
              <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-6">
                <img 
                  src="https://readdy.ai/api/search-image?query=Premium%20black%20cotton%20t-shirt%20displayed%20elegantly%20on%20clean%20background%2C%20professional%20product%20photography%2C%20soft%20natural%20lighting%2C%20high-end%20fashion%20styling%2C%20minimalist%20aesthetic%2C%20studio%20setup%20with%20subtle%20shadows&width=600&height=600&seq=featured-black-001&orientation=squarish"
                  alt="Black T-Shirt"
                  className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">Essential Black T-Shirt</h3>
              <p className="text-gray-600 mb-4">Timeless design crafted from soft fabric</p>
              <p className="text-2xl font-bold text-black">$29</p>
            </div>
          </div>
          
          <div className="text-center mt-12">
            <Link 
              href="/products"
              className="bg-black text-white px-8 py-3 rounded-md hover:bg-gray-800 transition-colors whitespace-nowrap cursor-pointer inline-block"
            >
              View All Products
            </Link>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-6 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="text-center">
              <div className="w-16 h-16 flex items-center justify-center mx-auto mb-6 bg-black text-white rounded-full">
                <i className="ri-shield-check-line text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Premium Quality</h3>
              <p className="text-gray-600">Carefully selected materials for lasting comfort and durability</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 flex items-center justify-center mx-auto mb-6 bg-black text-white rounded-full">
                <i className="ri-truck-line text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Free Shipping</h3>
              <p className="text-gray-600">Complimentary shipping on all orders over $50</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 flex items-center justify-center mx-auto mb-6 bg-black text-white rounded-full">
                <i className="ri-refresh-line text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Easy Returns</h3>
              <p className="text-gray-600">30-day return policy for your complete satisfaction</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-black text-white py-12 px-6">
        <div className="max-w-6xl mx-auto text-center">
          <div className="font-pacifico text-3xl mb-6">logo</div>
          <div className="flex justify-center space-x-8 mb-8">
            <Link href="/" className="hover:text-gray-300 transition-colors cursor-pointer">Home</Link>
            <Link href="/products" className="hover:text-gray-300 transition-colors cursor-pointer">Products</Link>
            <Link href="/about" className="hover:text-gray-300 transition-colors cursor-pointer">About</Link>
            <Link href="/contact" className="hover:text-gray-300 transition-colors cursor-pointer">Contact</Link>
          </div>
          <p className="text-gray-400">© 2024 Premium Essentials. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
