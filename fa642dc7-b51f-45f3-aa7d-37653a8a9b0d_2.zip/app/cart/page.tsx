'use client';

import Header from '@/components/Header';
import { useCartStore } from '@/lib/cartStore';
import Link from 'next/link';

export default function CartPage() {
  const { items, updateQuantity, removeItem, getTotalPrice, getTotalItems } = useCartStore();

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        
        <main className="px-6 py-12">
          <div className="max-w-4xl mx-auto text-center">
            <div className="w-16 h-16 flex items-center justify-center mx-auto mb-6">
              <i className="ri-shopping-cart-line text-4xl text-gray-400"></i>
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Your cart is empty</h1>
            <p className="text-gray-600 mb-8">Add some items to get started</p>
            <Link 
              href="/products"
              className="bg-black text-white px-8 py-3 rounded-md hover:bg-gray-800 transition-colors whitespace-nowrap cursor-pointer inline-block"
            >
              Shop Now
            </Link>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="px-6 py-12">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">Shopping Cart</h1>
          
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <div className="p-6">
              {items.map((item, index) => (
                <div key={`${item.id}-${item.size}`} className={`flex items-center space-x-4 ${index !== items.length - 1 ? 'border-b border-gray-200 pb-6 mb-6' : ''}`}>
                  <div className="w-20 h-20 bg-gray-100 rounded-md overflow-hidden flex-shrink-0">
                    <img 
                      src={item.image} 
                      alt={item.name}
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900">{item.name}</h3>
                    <p className="text-gray-600">Size: {item.size}</p>
                    <p className="text-lg font-bold text-black">${item.price}</p>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => updateQuantity(item.id, item.size, item.quantity - 1)}
                      className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded-md hover:bg-gray-50 cursor-pointer"
                    >
                      <i className="ri-subtract-line"></i>
                    </button>
                    <span className="w-8 text-center font-medium">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.size, item.quantity + 1)}
                      className="w-8 h-8 flex items-center justify-center border border-gray-300 rounded-md hover:bg-gray-50 cursor-pointer"
                    >
                      <i className="ri-add-line"></i>
                    </button>
                  </div>
                  
                  <button
                    onClick={() => removeItem(item.id, item.size)}
                    className="w-8 h-8 flex items-center justify-center text-red-500 hover:bg-red-50 rounded-md cursor-pointer"
                  >
                    <i className="ri-delete-bin-line"></i>
                  </button>
                </div>
              ))}
            </div>
            
            <div className="border-t border-gray-200 bg-gray-50 p-6">
              <div className="flex justify-between items-center mb-4">
                <span className="text-lg font-semibold">Total Items: {getTotalItems()}</span>
                <span className="text-2xl font-bold">Total: ${getTotalPrice()}</span>
              </div>
              
              <div className="flex space-x-4">
                <Link 
                  href="/products"
                  className="flex-1 border border-gray-300 text-gray-700 py-3 px-4 rounded-md hover:bg-white transition-colors text-center whitespace-nowrap cursor-pointer"
                >
                  Continue Shopping
                </Link>
                <Link
                  href="/checkout"
                  className="flex-1 bg-black text-white py-3 px-4 rounded-md hover:bg-gray-800 transition-colors whitespace-nowrap cursor-pointer text-center"
                >
                  Checkout
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}