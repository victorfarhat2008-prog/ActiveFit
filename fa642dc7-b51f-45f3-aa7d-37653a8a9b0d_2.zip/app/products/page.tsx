
'use client';

import Header from '@/components/Header';
import ProductCard from '@/components/ProductCard';

const products = [
  {
    id: '1',
    name: 'Classic White T-Shirt',
    price: 29,
    image: 'https://readdy.ai/api/search-image?query=Premium%20white%20cotton%20t-shirt%20on%20clean%20white%20background%2C%20minimalist%20product%20photography%2C%20soft%20natural%20lighting%2C%20high-end%20fashion%20styling%2C%20crisp%20fabric%20texture%2C%20studio%20photography%20setup%20with%20subtle%20shadows&width=400&height=400&seq=white-tshirt-001&orientation=squarish',
    description: 'Premium cotton blend for ultimate comfort and style. Perfect for everyday wear.'
  },
  {
    id: '2',
    name: 'Essential Black T-Shirt',
    price: 29,
    image: 'https://readdy.ai/api/search-image?query=Premium%20black%20cotton%20t-shirt%20on%20clean%20white%20background%2C%20minimalist%20product%20photography%2C%20soft%20natural%20lighting%2C%20high-end%20fashion%20styling%2C%20crisp%20fabric%20texture%2C%20studio%20photography%20setup%20with%20subtle%20shadows&width=400&height=400&seq=black-tshirt-001&orientation=squarish',
    description: 'Timeless black tee crafted from soft, breathable fabric. A wardrobe essential.'
  }
];

export default function ProductsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="px-6 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Our Collection</h1>
            <p className="text-xl text-gray-600">Premium quality t-shirts for every occasion</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {products.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}
