'use client';

import Link from 'next/link';
import { useCartStore } from '@/lib/cartStore';

export default function Header() {
  const getTotalItems = useCartStore(state => state.getTotalItems);

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/" className="font-pacifico text-2xl text-black">
            logo
          </Link>
          
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-black transition-colors cursor-pointer">
              Home
            </Link>
            <Link href="/products" className="text-gray-700 hover:text-black transition-colors cursor-pointer">
              Products
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-black transition-colors cursor-pointer">
              About
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-black transition-colors cursor-pointer">
              Contact
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Link href="/cart" className="relative cursor-pointer">
              <div className="w-6 h-6 flex items-center justify-center">
                <i className="ri-shopping-cart-line text-xl"></i>
              </div>
              <span className="absolute -top-2 -right-2 bg-black text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {getTotalItems()}
              </span>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}