
'use client';

import { useState } from 'react';
import { useCartStore } from '@/lib/cartStore';

interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  description: string;
}

interface ProductCardProps {
  product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
  const [selectedSize, setSelectedSize] = useState('M');
  const [showSuccess, setShowSuccess] = useState(false);
  const addItem = useCartStore(state => state.addItem);

  const sizes = ['XS', 'S', 'M', 'L', 'XL'];

  const handleAddToCart = () => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      size: selectedSize,
      image: product.image
    });
    
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 2000);
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
      <div className="aspect-square bg-gray-50">
        <img 
          src={product.image} 
          alt={product.name}
          className="w-full h-full object-cover object-top"
        />
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-2">{product.name}</h3>
        <p className="text-gray-600 mb-4">{product.description}</p>
        <p className="text-2xl font-bold text-black mb-4">${product.price}</p>
        
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">Size</label>
          <div className="flex space-x-2">
            {sizes.map(size => (
              <button
                key={size}
                onClick={() => setSelectedSize(size)}
                className={`px-3 py-2 border rounded-md text-sm whitespace-nowrap cursor-pointer transition-colors ${
                  selectedSize === size
                    ? 'border-black bg-black text-white'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>
        
        <button
          onClick={handleAddToCart}
          className="w-full bg-black text-white py-3 px-4 rounded-md hover:bg-gray-800 transition-colors whitespace-nowrap cursor-pointer"
        >
          Add to Cart
        </button>
        
        {showSuccess && (
          <div className="mt-3 p-2 bg-green-100 text-green-800 text-sm rounded-md text-center">
            Added to cart successfully!
          </div>
        )}
      </div>
    </div>
  );
}
